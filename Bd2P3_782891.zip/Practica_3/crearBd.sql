
---Creamos la base de datos y damos permisos
CREATE DATABASE Practica3 WITH OWNER postgres;
GRANT ALL PRIVILEGES ON DATABASE Practica3 TO postgres;
